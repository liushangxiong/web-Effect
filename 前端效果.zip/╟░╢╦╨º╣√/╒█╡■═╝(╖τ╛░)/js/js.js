$(function(){
	$(".son").hover(function(){
	// 文字和遮罩消失
        $(this).find(".font").css({display:'none'});
        $(this).find(".cover").css({display:'none'});
        // .son的盒子变宽,兄弟盒子变窄。
        $(this).stop().animate({width:"400px"},700).siblings('.son').stop().animate({width:"160px"},700);
        // .pic位移。.pic兄弟位移。
        $(this).find(".pic").stop().animate({left:"0px"},700).parents(".son").siblings('.son').find(".pic").stop().animate({left:"-120px"},700);
	},function(){
	// 文字和遮罩显示
        $(".son").find(".font").css({display:'block'});
        $(".son").find(".cover").css({display:'block'});
        // .son的盒子恢复。
        $(this).stop().animate({width:"200px"}).siblings('.son').stop().animate({width:"200px"});
        // .pic位移。.pic兄弟位移。
        $(this).find(".pic").stop().animate({left:"-100px"});
	})
})